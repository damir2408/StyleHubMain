const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      createdAt TEXT NOT NULL
    )
  `);
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true });
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body || {};

    if (!name?.trim() || !email?.trim() || !password?.trim()) {
      return res.status(400).json({ message: 'Все поля обязательны.' });
    }

    if (password.trim().length < 4) {
      return res.status(400).json({ message: 'Пароль должен содержать минимум 4 символа.' });
    }

    const normalizedEmail = email.trim().toLowerCase();

    db.get('SELECT id FROM users WHERE email = ?', [normalizedEmail], async (selectErr, row) => {
      if (selectErr) {
        return res.status(500).json({ message: 'Ошибка базы данных.' });
      }

      if (row) {
        return res.status(400).json({ message: 'Пользователь с такой почтой уже зарегистрирован.' });
      }

      const createdAt = new Date().toISOString();
      const passwordHash = await bcrypt.hash(password.trim(), 10);

      db.run(
        'INSERT INTO users (name, email, password, createdAt) VALUES (?, ?, ?, ?)',
        [name.trim(), normalizedEmail, passwordHash, createdAt],
        function (insertErr) {
          if (insertErr) {
            return res.status(500).json({ message: 'Не удалось сохранить пользователя.' });
          }

          return res.status(201).json({
            ok: true,
            user: {
              id: this.lastID,
              name: name.trim(),
              email: normalizedEmail,
              createdAt
            }
          });
        }
      );
    });
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка сервера.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!email?.trim() || !password?.trim()) {
      return res.status(400).json({ message: 'Введите почту и пароль.' });
    }

    const normalizedEmail = email.trim().toLowerCase();

    db.get(
      'SELECT id, name, email, password, createdAt FROM users WHERE email = ?',
      [normalizedEmail],
      async (selectErr, user) => {
        if (selectErr) {
          return res.status(500).json({ message: 'Ошибка базы данных.' });
        }

        if (!user) {
          return res.status(400).json({ message: 'Неверная почта или пароль.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
          return res.status(400).json({ message: 'Неверная почта или пароль.' });
        }

        return res.json({
          ok: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            createdAt: user.createdAt
          }
        });
      }
    );
  } catch (error) {
    return res.status(500).json({ message: 'Ошибка сервера.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server started on http://localhost:${PORT}`);
});

import React from "react";
import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { formatPrice } from "../utils/formatPrice.js";

export default function ProductCard({ product }) {
  const { addToCart, favorites, toggleFavorite } = useStore();
  const favorite = favorites.includes(product.id);

  return (
    <article className="product-card">
      <button
        className={`favorite-btn ${favorite ? "active" : ""}`}
        onClick={() => toggleFavorite(product.id)}
        aria-label="Добавить в избранное"
      >
        ♥
      </button>

      <div
        className="product-image"
        style={
          product.image.startsWith("linear-gradient")
            ? { background: product.image }
            : undefined
        }
      >
        {!product.image.startsWith("linear-gradient") && (
          <img src={product.image} alt={product.name} />
        )}
        <span className="product-badge">{product.badge}</span>
      </div>

      <div className="product-body">
        <div className="product-line">
          <span className="product-category">{product.category}</span>
          <span className="rating">★ {product.rating}</span>
        </div>

        <Link className="product-title" to={`/product/${product.id}`}>
          {product.name}
        </Link>

        <p className="product-description">{product.description}</p>

        <div className="price-row">
          <strong>{formatPrice(product.price)}</strong>
          <span>{formatPrice(product.oldPrice)}</span>
        </div>

        <div className="card-actions">
          <button className="button primary small" onClick={() => addToCart(product)}>
            В корзину
          </button>
          <Link className="button secondary small" to={`/product/${product.id}`}>
            Подробнее
          </Link>
        </div>
      </div>
    </article>
  );
}

import React from "react";
import { useStore } from "../context/StoreContext.jsx";

export default function FilterBar() {
  const { search, category, sort, setSearch, setCategory, setSort } = useStore();

  return (
    <div className="filter-bar">
      <input
        type="text"
        placeholder="Поиск по названию, цвету или категории..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <select value={category} onChange={(e) => setCategory(e.target.value)}>
        <option value="all">Все категории</option>
        <option value="Худи">Худи</option>
        <option value="Футболки">Футболки</option>
        <option value="Куртки">Куртки</option>
        <option value="Брюки">Брюки</option>
      </select>

      <select value={sort} onChange={(e) => setSort(e.target.value)}>
        <option value="featured">По умолчанию</option>
        <option value="rating">По рейтингу</option>
        <option value="price-asc">Цена ↑</option>
        <option value="price-desc">Цена ↓</option>
      </select>
    </div>
  );
}

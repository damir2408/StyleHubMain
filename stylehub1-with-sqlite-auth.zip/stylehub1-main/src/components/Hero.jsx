import React from "react";
import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="hero-section">
      <div className="container hero-grid">
        <div>
          <span className="eyebrow">НОВАЯ КОЛЛЕКЦИЯ / ЕЖЕДНЕВНЫЙ СТИЛЬ</span>
          <h1>Одежда и базовые вещи, которые легко впишутся в любой гардероб.</h1>
          <p className="hero-text">
            Выбирайте актуальные модели на каждый день: комфортные худи, футболки,
            куртки и брюки с удобной посадкой, современным дизайном и быстрой доставкой.
          </p>
          <div className="hero-actions">
            <Link to="/catalog" className="button primary">Смотреть каталог</Link>
            <Link to="/about" className="button secondary">Доставка и сервис</Link>
          </div>
          <div className="hero-metrics">
            <div><strong>12</strong><span>Моделей в каталоге</span></div>
            <div><strong>4</strong><span>Основные категории</span></div>
            <div><strong>14 дней</strong><span>На возврат товара</span></div>
          </div>
        </div>
        <div className="hero-card">
          <div className="hero-badge">Бесплатная доставка от 30 000 ₸</div>
          <div className="hero-image"></div>
          <div className="hero-card-bottom">
            <h3>Повседневная коллекция StyleHub</h3>
            <p>Чистый силуэт, спокойная палитра и удобные вещи для города, учебы и отдыха.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

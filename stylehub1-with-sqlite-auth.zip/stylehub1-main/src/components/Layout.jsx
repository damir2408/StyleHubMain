import React from "react";
import { Link, NavLink } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Layout({ children }) {
  const { cartCount, favorites } = useStore();
  const { isAuthenticated, currentUser, logout } = useAuth();

  return (
    <div className="app-shell">
      <div className="promo-bar">
        <div className="container promo-row">
          <span>Бесплатная доставка по Казахстану от 30 000 ₸</span>
          <span>Обмен и возврат в течение 14 дней</span>
        </div>
      </div>

      <header className="topbar">
        <div className="container nav-row">
          <Link to="/" className="brand">STYLEHUB</Link>

          <nav className="nav-links">
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/catalog">Каталог</NavLink>
            <NavLink to="/favorites">Избранное</NavLink>
            <NavLink to="/cart">Корзина</NavLink>
            <NavLink to="/about">Покупателям</NavLink>
            {isAuthenticated ? <NavLink to="/account">Кабинет</NavLink> : <NavLink to="/login">Вход</NavLink>}
          </nav>

          <div className="nav-status auth-status">
            <span>♥ {favorites.length}</span>
            <span>🛒 {cartCount}</span>
            {isAuthenticated ? (
              <div className="header-user">
                <Link to="/account" className="user-pill">{currentUser?.name}</Link>
                <button className="logout-link" onClick={logout}>Выйти</button>
              </div>
            ) : (
              <Link to="/register" className="user-pill">Регистрация</Link>
            )}
          </div>
        </div>
      </header>

      <main>{children}</main>

      <footer className="footer">
        <div className="container footer-grid">
          <div>
            <h3>StyleHub</h3>
            <p>
              Онлайн-магазин повседневной одежды с актуальными моделями, удобным каталогом,
              личным кабинетом и простым оформлением заказа.
            </p>
          </div>
          <div>
            <h4>Покупателям</h4>
            <p>Каталог, избранное, корзина, доставка, сервис и вход в аккаунт.</p>
          </div>
          <div>
            <h4>Информация</h4>
            <p>Оплата при оформлении, возврат в течение 14 дней, поддержка покупателей каждый день.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

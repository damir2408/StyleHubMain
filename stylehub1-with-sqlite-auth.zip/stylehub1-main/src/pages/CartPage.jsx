import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";
import { formatPrice } from "../utils/formatPrice.js";

export default function CartPage() {
  const { cart, cartTotal, changeQty, removeFromCart } = useStore();
  const discount = cartTotal >= 30000 ? 3000 : 0;
  const delivery = cartTotal === 0 ? 0 : cartTotal >= 30000 ? 0 : 2000;
  const finalTotal = Math.max(0, cartTotal - discount + delivery);
  const [showPayment, setShowPayment] = useState(false);

  return (
    <section className="section">
      <div className="container cart-layout">
        <div>
          <div className="section-header">
            <div>
              <span className="eyebrow">корзина</span>
              <h2>Ваш заказ</h2>
            </div>
          </div>

          {cart.length ? (
            <div className="cart-list">
              {cart.map((item) => (
                <article className="cart-item" key={item.id}>
                  <div className="cart-thumb" style={{ background: item.image }}></div>

                  <div className="cart-info">
                    <h3>{item.name}</h3>
                    <p>{formatPrice(item.price)}</p>
                  </div>

                  <div className="qty-box">
                    <button onClick={() => changeQty(item.id, -1)}>-</button>
                    <span>{item.qty}</span>
                    <button onClick={() => changeQty(item.id, 1)}>+</button>
                  </div>

                  <strong>{formatPrice(item.price * item.qty)}</strong>

                  <button className="remove-btn" onClick={() => removeFromCart(item.id)}>
                    Удалить
                  </button>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <h3>Корзина пока пуста</h3>
              <p>Добавьте понравившиеся товары из каталога, чтобы оформить заказ.</p>
              <Link className="button primary" to="/catalog">Перейти в каталог</Link>
            </div>
          )}
        </div>

        <aside className="summary-card">
          <h3>Сводка заказа</h3>
          <div className="summary-row">
            <span>Товаров</span>
            <strong>{cart.length}</strong>
          </div>
          <div className="summary-row">
            <span>Стоимость товаров</span>
            <strong>{formatPrice(cartTotal)}</strong>
          </div>
          <div className="summary-row">
            <span>Скидка</span>
            <strong>- {formatPrice(discount)}</strong>
          </div>
          <div className="summary-row">
            <span>Доставка</span>
            <strong>{formatPrice(delivery)}</strong>
          </div>
          <div className="summary-row total-row">
            <span>К оплате</span>
            <strong>{formatPrice(finalTotal)}</strong>
          </div>
          <button className="button primary wide" onClick={() => setShowPayment(true)}>Оформить заказ</button>
          <p className="summary-note">Бесплатная доставка действует для заказов от 30 000 ₸.</p>
        </aside>
      </div>
    
      {showPayment && (
        <div className="payment-modal">
          <div className="payment-window">
            <h3>Оплата заказа</h3>
            <p>Сумма к оплате:</p>
            <strong>{formatPrice(finalTotal)}</strong>

            <div className="fake-pay-methods">
              <button className="pay-method">💳 Банковская карта</button>
              <button className="pay-method">📱 Kaspi Pay</button>
              <button className="pay-method">🪙 Наличные</button>
            </div>

            <button className="button primary wide" onClick={() => {alert("Оплата выполнена (демо)"); setShowPayment(false);}}>
              Подтвердить оплату
            </button>

            <button className="button wide" onClick={() => setShowPayment(false)}>
              Отмена
            </button>
          </div>
        </div>
      )}

</section>
  );
}

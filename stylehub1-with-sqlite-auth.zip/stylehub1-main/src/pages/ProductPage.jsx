import React from "react";
import { Link, useParams } from "react-router-dom";
import { products } from "../data/products.js";
import { useStore } from "../context/StoreContext.jsx";
import { formatPrice } from "../utils/formatPrice.js";

export default function ProductPage() {
  const { id } = useParams();
  const { addToCart, toggleFavorite, favorites } = useStore();

  const product = products.find((item) => item.id === Number(id));

  if (!product) {
    return (
      <section className="section">
        <div className="container empty-state">
          <h2>Товар не найден</h2>
          <Link className="button primary" to="/catalog">Назад в каталог</Link>
        </div>
      </section>
    );
  }

  return (
    <section className="section">
      <div className="container product-layout">
        <div
          className="single-image"
          style={
            product.image.startsWith("linear-gradient")
              ? { background: product.image }
              : undefined
          }
        >
          {!product.image.startsWith("linear-gradient") && (
            <img src={product.image} alt={product.name} />
          )}
        </div>

        <div className="single-info">
          <span className="eyebrow">{product.badge}</span>
          <h2>{product.name}</h2>
          <p className="single-desc">{product.description}</p>

          <div className="single-meta">
            <div><span>Категория</span><strong>{product.category}</strong></div>
            <div><span>Цвет</span><strong>{product.color}</strong></div>
            <div><span>Рейтинг</span><strong>{product.rating}</strong></div>
          </div>

          <div className="sizes-row">
            {product.sizes.map((size) => <span key={size}>{size}</span>)}
          </div>

          <div className="price-row large">
            <strong>{formatPrice(product.price)}</strong>
            <span>{formatPrice(product.oldPrice)}</span>
          </div>

          <div className="service-points">
            <div>Быстрая доставка</div>
            <div>Возврат 14 дней</div>
            <div>Удобная оплата</div>
          </div>

          <div className="card-actions">
            <button className="button primary" onClick={() => addToCart(product)}>Добавить в корзину</button>
            <button className="button secondary" onClick={() => toggleFavorite(product.id)}>
              {favorites.includes(product.id) ? "Убрать из избранного" : "В избранное"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useStore } from "../context/StoreContext.jsx";

export default function AccountPage() {
  const { currentUser, logout } = useAuth();
  const { cartCount, favorites } = useStore();

  return (
    <section className="section">
      <div className="container account-grid">
        <div className="account-card large">
          <span className="eyebrow">личный кабинет</span>
          <h1>{currentUser?.name}</h1>
          <p className="auth-muted">
            Аккаунт сохранен в браузере. После обновления страницы вход не сбросится,
            пока вы сами не выйдете из профиля.
          </p>
          <div className="account-meta">
            <div>
              <span>E-mail</span>
              <strong>{currentUser?.email}</strong>
            </div>
            <div>
              <span>Дата регистрации</span>
              <strong>
                {currentUser?.createdAt
                  ? new Date(currentUser.createdAt).toLocaleDateString("ru-RU")
                  : "—"}
              </strong>
            </div>
          </div>
          <div className="card-actions">
            <Link className="button primary" to="/catalog">Перейти в каталог</Link>
            <button className="button secondary" onClick={logout}>Выйти</button>
          </div>
        </div>

        <div className="account-column">
          <div className="account-card">
            <h3>Ваш магазин</h3>
            <div className="account-stat"><span>Товаров в корзине</span><strong>{cartCount}</strong></div>
            <div className="account-stat"><span>Избранных товаров</span><strong>{favorites.length}</strong></div>
            <div className="account-stat"><span>Статус аккаунта</span><strong>Активен</strong></div>
          </div>

          <div className="account-card">
            <h3>Что уже работает</h3>
            <ul className="auth-points compact">
              <li>Регистрация нового пользователя</li>
              <li>Вход и выход из аккаунта</li>
              <li>Сохранение авторизации в localStorage</li>
              <li>Остальная логика магазина сохранена</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

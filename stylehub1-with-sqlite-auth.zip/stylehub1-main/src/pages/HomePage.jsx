import React from "react";
import Hero from "../components/Hero.jsx";
import ProductCard from "../components/ProductCard.jsx";
import { products } from "../data/products.js";

const advantages = [
  {
    title: "Быстрая доставка",
    text: "Оперативная отправка по Казахстану и удобное получение заказа в вашем городе."
  },
  {
    title: "Актуальный ассортимент",
    text: "Базовые и трендовые модели для повседневного гардероба без лишних деталей."
  },
  {
    title: "Удобный выбор",
    text: "Поиск, фильтры по категориям и сортировка помогают быстро найти нужную модель."
  }
];

const categories = [
  { name: "Худи", text: "Комфортные модели для прохладной погоды и многослойных образов." },
  { name: "Футболки", text: "База на каждый день с лаконичным дизайном и удобной посадкой." },
  { name: "Куртки", text: "Практичные варианты для города, межсезонья и активного дня." },
  { name: "Брюки", text: "Современный крой, свобода движений и универсальные оттенки." }
];

const reviews = [
  {
    name: "Алина, Астана",
    text: "Очень аккуратный магазин: все понятно, товары легко добавить в корзину, а описание выглядит реально."
  },
  {
    name: "Тимур, Алматы",
    text: "Понравилась простая навигация и чистый дизайн. Ничего лишнего, все как у обычного современного магазина."
  },
  {
    name: "Мария, Караганда",
    text: "Хорошо выглядит на телефоне и на ноутбуке. Каталог и карточки товаров смотрятся живо и аккуратно."
  }
];

export default function HomePage() {
  const featured = products.slice(0, 4);

  return (
    <>
      <Hero />

      <section className="section benefits-section">
        <div className="container benefits-grid">
          {advantages.map((item) => (
            <div className="benefit-card" key={item.title}>
              <span className="benefit-icon">✦</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">популярное</span>
              <h2>Популярные товары</h2>
            </div>
            <p>
              Подборка моделей, которые хорошо смотрятся в повседневном гардеробе и легко сочетаются между собой.
            </p>
          </div>

          <div className="product-grid">
            {featured.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        </div>
      </section>

      <section className="section alt">
        <div className="container feature-grid">
          {categories.map((item) => (
            <div className="feature-box" key={item.name}>
              <span className="mini-label">Категория</span>
              <h3>{item.name}</h3>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container subscribe-box">
          <div>
            <span className="eyebrow">скидки и новости</span>
            <h2>Подпишитесь на обновления магазина</h2>
            <p>Получайте информацию о новинках, специальных предложениях и сезонных скидках.</p>
          </div>
          <div className="subscribe-form">
            <input type="email" placeholder="Ваш e-mail" />
            <button className="button primary">Подписаться</button>
          </div>
        </div>
      </section>

      <section className="section alt review-section">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">отзывы</span>
              <h2>Покупатели отмечают удобство и стиль</h2>
            </div>
            <p>Короткие отзывы о визуале магазина, навигации и общем впечатлении от каталога.</p>
          </div>

          <div className="reviews-grid">
            {reviews.map((review) => (
              <article className="review-card" key={review.name}>
                <div className="rating-row">★★★★★</div>
                <p>{review.text}</p>
                <strong>{review.name}</strong>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

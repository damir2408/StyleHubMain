import React from "react";
import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <section className="section">
      <div className="container empty-state">
        <h1>404</h1>
        <p>Такой страницы не существует.</p>
        <Link className="button primary" to="/">На главную</Link>
      </div>
    </section>
  );
}

import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const redirectTo = location.state?.from || "/account";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const result = await login(form);
    if (!result.ok) {
      setError(result.message);
      return;
    }

    navigate(redirectTo);
  };

  return (
    <section className="section auth-section">
      <div className="container auth-layout">
        <div className="auth-side">
          <span className="eyebrow">личный кабинет</span>
          <h1>Вход в аккаунт</h1>
          <p>
            Войдите в свой профиль, чтобы данные сохранялись в браузере и вы могли
            быстро продолжить покупки с того же устройства.
          </p>
          <ul className="auth-points">
            <li>Сохранение аккаунта после перезагрузки страницы</li>
            <li>Быстрый доступ к личному кабинету</li>
            <li>Простая регистрация без лишних шагов</li>
          </ul>
        </div>

        <form className="auth-card" onSubmit={handleSubmit}>
          <h2>Добро пожаловать</h2>
          <p className="auth-muted">Введите почту и пароль для входа в магазин.</p>

          <label>
            <span>E-mail</span>
            <input
              type="email"
              placeholder="Введите e-mail"
              value={form.email}
              onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
              required
            />
          </label>

          <label>
            <span>Пароль</span>
            <input
              type="password"
              placeholder="Введите пароль"
              value={form.password}
              onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))}
              required
            />
          </label>

          {error ? <div className="auth-message error">{error}</div> : null}

          <button type="submit" className="button primary wide">Войти</button>

          <div className="auth-switch">
            <span>Еще нет аккаунта?</span>
            <Link to="/register">Зарегистрироваться</Link>
          </div>
        </form>
      </div>
    </section>
  );
}

import React from "react";
import FilterBar from "../components/FilterBar.jsx";
import ProductCard from "../components/ProductCard.jsx";
import { useStore } from "../context/StoreContext.jsx";

export default function CatalogPage() {
  const { filteredProducts } = useStore();

  return (
    <section className="section">
      <div className="container">
        <div className="section-header catalog-head">
          <div>
            <span className="eyebrow">каталог</span>
            <h2>Коллекция одежды</h2>
          </div>
          <p>Найдено товаров: {filteredProducts.length}</p>
        </div>

        <FilterBar />

        <div className="product-grid">
          {filteredProducts.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      </div>
    </section>
  );
}

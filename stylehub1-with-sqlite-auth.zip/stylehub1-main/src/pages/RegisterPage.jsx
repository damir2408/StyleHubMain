import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (form.password.length < 4) {
      setError("Пароль должен содержать минимум 4 символа.");
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError("Пароли не совпадают.");
      return;
    }

    const result = await register({ name: form.name, email: form.email, password: form.password });
    if (!result.ok) {
      setError(result.message);
      return;
    }

    navigate("/account");
  };

  return (
    <section className="section auth-section">
      <div className="container auth-layout">
        <div className="auth-side">
          <span className="eyebrow">регистрация</span>
          <h1>Создайте аккаунт</h1>
          <p>
            Зарегистрируйтесь один раз, и вход будет сохраняться в браузере. Это удобно
            для демонстрации обычного интернет-магазина без изменения остальной логики.
          </p>
          <ul className="auth-points">
            <li>Имя и почта пользователя хранятся локально</li>
            <li>Аккаунт доступен после обновления страницы</li>
            <li>Можно выйти и снова войти в любой момент</li>
          </ul>
        </div>

        <form className="auth-card" onSubmit={handleSubmit}>
          <h2>Новый аккаунт</h2>
          <p className="auth-muted">Заполните форму, чтобы создать личный кабинет.</p>

          <label>
            <span>Имя</span>
            <input
              type="text"
              placeholder="Введите имя"
              value={form.name}
              onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
              required
            />
          </label>

          <label>
            <span>E-mail</span>
            <input
              type="email"
              placeholder="Введите e-mail"
              value={form.email}
              onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
              required
            />
          </label>

          <label>
            <span>Пароль</span>
            <input
              type="password"
              placeholder="Минимум 4 символа"
              value={form.password}
              onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))}
              required
            />
          </label>

          <label>
            <span>Повторите пароль</span>
            <input
              type="password"
              placeholder="Повторите пароль"
              value={form.confirmPassword}
              onChange={(e) => setForm((prev) => ({ ...prev, confirmPassword: e.target.value }))}
              required
            />
          </label>

          {error ? <div className="auth-message error">{error}</div> : null}

          <button type="submit" className="button primary wide">Создать аккаунт</button>

          <div className="auth-switch">
            <span>Уже есть аккаунт?</span>
            <Link to="/login">Войти</Link>
          </div>
        </form>
      </div>
    </section>
  );
}

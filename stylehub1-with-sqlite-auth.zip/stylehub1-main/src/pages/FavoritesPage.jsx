import React from "react";
import ProductCard from "../components/ProductCard.jsx";
import { useStore } from "../context/StoreContext.jsx";

export default function FavoritesPage() {
  const { favorites, products } = useStore();
  const list = products.filter((item) => favorites.includes(item.id));

  return (
    <section className="section">
      <div className="container">
        <div className="section-header">
          <div>
            <span className="eyebrow">избранное</span>
            <h2>Сохраненные товары</h2>
          </div>
          <p>Товаров в избранном: {list.length}</p>
        </div>

        {list.length ? (
          <div className="product-grid">
            {list.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        ) : (
          <div className="empty-state">
            <h3>Пока нет сохраненных товаров</h3>
            <p>Добавьте понравившиеся позиции из каталога, чтобы вернуться к ним позже.</p>
          </div>
        )}
      </div>
    </section>
  );
}

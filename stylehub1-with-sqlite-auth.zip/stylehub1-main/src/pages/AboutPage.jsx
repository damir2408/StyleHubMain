import React from "react";

export default function AboutPage() {
  return (
    <section className="section">
      <div className="container about-stack">
        <div className="about-grid">
          <div className="about-card">
            <span className="eyebrow">о магазине</span>
            <h2>StyleHub — удобный онлайн-магазин повседневной одежды</h2>
            <p>
              Мы собрали базовые и актуальные модели для тех, кто ценит комфорт,
              аккуратный внешний вид и понятный процесс покупки без лишних шагов.
            </p>
          </div>

          <div className="about-card">
            <h3>Что вы найдете на сайте</h3>
            <ul className="about-list">
              <li>Каталог с поиском, фильтрами и сортировкой</li>
              <li>Карточки товаров с описанием, размерами и ценами</li>
              <li>Избранное для сохранения понравившихся моделей</li>
              <li>Корзину с быстрым изменением количества товаров</li>
              <li>Удобный интерфейс для компьютера и телефона</li>
            </ul>
          </div>
        </div>

        <div className="info-grid">
          <div className="about-card">
            <h3>Доставка</h3>
            <p>Доставка по Казахстану. Заказы от 30 000 ₸ отправляются бесплатно.</p>
          </div>
          <div className="about-card">
            <h3>Оплата</h3>
            <p>Оплата доступна при оформлении заказа. Все суммы отображаются сразу и без скрытых платежей.</p>
          </div>
          <div className="about-card">
            <h3>Возврат</h3>
            <p>Если товар не подошел, вы можете оформить обмен или возврат в течение 14 дней.</p>
          </div>
          <div className="about-card">
            <h3>Поддержка</h3>
            <p>Мы помогаем с выбором размера, оформлением и общими вопросами по заказу.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

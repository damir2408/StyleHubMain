import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

const AuthContext = createContext(null);

const readLocal = (key, fallback) => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
};

async function request(url, options = {}) {
  try {
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      },
      ...options
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return { ok: false, message: data.message || "Ошибка запроса." };
    }

    return { ok: true, data };
  } catch {
    return { ok: false, message: "Не удалось подключиться к серверу." };
  }
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(() => readLocal("stylehub-current-user", null));

  useEffect(() => {
    localStorage.setItem("stylehub-current-user", JSON.stringify(currentUser));
  }, [currentUser]);

  const register = async ({ name, email, password }) => {
    const result = await request("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password })
    });

    if (!result.ok) {
      return { ok: false, message: result.message };
    }

    const user = result.data.user;
    setCurrentUser(user);
    return { ok: true, user };
  };

  const login = async ({ email, password }) => {
    const result = await request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });

    if (!result.ok) {
      return { ok: false, message: result.message };
    }

    const user = result.data.user;
    setCurrentUser(user);
    return { ok: true, user };
  };

  const logout = () => setCurrentUser(null);

  const value = useMemo(() => ({
    users: [],
    currentUser,
    isAuthenticated: Boolean(currentUser),
    register,
    login,
    logout
  }), [currentUser]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth должен использоваться внутри AuthProvider");
  }
  return context;
}
